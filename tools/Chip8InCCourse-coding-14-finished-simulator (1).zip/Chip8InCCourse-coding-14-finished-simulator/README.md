# Chip8InCCourse
This repository has been created for the Chip8 in C programming course which will be available on Udemy soon.
This is a chip8 emulator repository created for the development of a "How to develop a Chip8 emulator" course
